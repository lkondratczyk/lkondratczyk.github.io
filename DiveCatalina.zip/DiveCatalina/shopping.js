				document.getElementById("name-error").className = "error-reveal";
				document.getElementById("phone-error").className = "error-reveal";
				document.getElementById("date-error").className = "error-reveal";
				
				//var x = document.forms["payform"]["os1"].value;
					//if (x == null || x == "") {
						//alert("Name must be filled out");
						//return false;
					//}
				
				function submitAction(button){
					if(button == ""){
						
					}
				}
				
				function validateForm() {
					var hasErrors = false;	
				}
				
				function populateInputs(){		
					var monthOptions = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
					var monthSelect = document.getElementById("month-input");
					populateInput(monthOptions, monthSelect);
					
					var monthDays = ["31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"];
					var daySelect = document.getElementById("day-input");
					populateInput(getDaySet(monthDays[(new Date()).getMonth()]), daySelect);
					
					var yearSelect = document.getElementById("year-input");
					populateInput(getYearSet(), yearSelect);
					
					setDefaultDate(monthSelect, daySelect, yearSelect);
					
					document.getElementById('month-input').onchange = function(){
						populateInput(getDaySet(monthDays[this.selectedIndex]), daySelect);
					}
					
					var timeOptions = ["9:00 am", "10:00 am", "11:15 am", "12:15 pm", "1:30 pm", "2:30 pm", "3:45 pm"];
					var timeSelect = document.getElementById("time-input");
					populateInput(timeOptions, timeSelect);
				}
				
				function populateInput(newOptions, optionParent){
					while (optionParent.options.length > 0) { 
						optionParent.options.remove(0); 
					}
					var entries = newOptions.length;
					for(var i = 0; i < entries; i++){
						var option = document.createElement("option");
						option.text = newOptions[i];
						optionParent.appendChild(option);
					}
				}
				
				function setDefaultDate(month, day, year){
					var today = new Date();
					month.selectedIndex = today.getMonth();
					day.selectedIndex = today.getDate() - 1;
					year.selectedIndex = 0;
				}
				
				function getDaySet(limit){
					var dateSet = [];
					for(var i = 1; i <= limit; i++){
						dateSet.push(i);
					}
					if(limit == "28" && (new Date()).getYear() % 4 == 0){
						dateSet.push("29");
					}
					return dateSet;
				}
				
				function getYearSet(){
					var yearSet = [];
					var thisYear = (new Date()).getFullYear();
					for(var i = 0; i < 5; i++){
						yearSet.push(thisYear + i);
					}
					return yearSet;
				}
				
				populateInputs();